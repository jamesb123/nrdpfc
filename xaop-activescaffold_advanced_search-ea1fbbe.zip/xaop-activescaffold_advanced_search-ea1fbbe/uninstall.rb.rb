# This should somehow drop the table too, unfortunately this is impossible to do without messing up data for the user
system "script/destroy model --skip-migration SavedAdvancedSearch"